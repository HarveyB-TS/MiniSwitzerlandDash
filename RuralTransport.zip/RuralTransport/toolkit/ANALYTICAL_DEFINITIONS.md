# Analytical definitions — v8.2 analysis-ready network profiler

## Source-preserving principle

The toolkit reports scheduled provision represented in the supplied GTFS. It does not infer whether provision is integrated, sufficient, useful to passengers or commercially sustainable.

## Candidate stop

A GTFS stop whose supplied coordinates fall inside the candidate polygon or the explicitly selected buffer.

## Route serving candidate

A GTFS `route_id` for which at least one trip is active on the selected date and that trip has a `stop_times` record at a candidate stop. A shape crossing the polygon is insufficient.

## Active trip

A source `trip_id` whose `service_id` is active on the selected date after applying `calendar.txt` and `calendar_dates.txt`.

## Stop place

For pre-refined summaries:

1. use `parent_station` where the source feed supplies it;
2. otherwise keep the source `stop_id` as its own stop place.

This avoids automatically clustering geographically nearby stops and preserves the source hierarchy.

## Stop-place activity / hub ranking

Stop places are ranked by the number of unique active relevant trips calling there on the selected date. The user controls how many top-ranked stop places receive hub departure-board outputs.

This is an activity ranking only. It is not a measure of strategic importance, demand or interchange quality.

## Service pattern

A deterministic tuple of:

`route_id + direction_id + exact ordered stop_id sequence`

Headsigns and route names are retained as source information but are not used to group patterns.

## Pattern complexity measures

For each route the profiler reports:
- active trips;
- exact service patterns;
- dominant-pattern share = trips on the most common exact pattern / active trips on the route;
- single-trip patterns.

These are descriptive measures and are not scored.

## Scheduled call

One `stop_times` record belonging to an active relevant trip at a candidate stop.

## Hourly profile

For each hour (GTFS hours 00–29) the profiler reports:
- unique active trips with at least one candidate call during that hour; and
- candidate stop calls during that hour.

The first avoids counting the same trip repeatedly within the hour; the second describes the intensity of scheduled activity.

## External / feeder trip

An active relevant trip with at least one scheduled stop inside the candidate and at least one scheduled stop outside it.

A trip may be classified as:
- arriving from outside, where an outside stop occurs before its first candidate stop;
- departing to outside, where an outside stop occurs after its last candidate stop;
- both, for a through trip.

Counts use unique `trip_id` values, not candidate stop calls.

## External-service gap

Outbound gap measures use the scheduled time at the last candidate stop before the trip continues outside the candidate.

The profiler reports:
- median gap between outward external trips; and
- maximum gap between outward external trips during the user-defined daytime window.

No judgement is applied to whether a given gap is acceptable.

## Direct external destination

A stop place outside the candidate is directly reachable where it occurs later in the same active trip after a candidate stop. This represents a scheduled direct link and assumes no interchange.

## User-specified gateway

A gateway is included only where the analyst explicitly supplies a stop/place name or GTFS ID.

Matching is:
- exact after case/punctuation normalisation for source stop/place names; or
- exact source stop_id / parent_station ID.

No fuzzy name matching or proximity-based interchange assumption is used. Unmatched terms are reported.

## Route timetable matrix

For each exact service pattern active on the selected date:
- stops are rows in source stop order;
- trips are columns ordered by scheduled time at the first stop;
- cells contain source scheduled arrival/departure times.

The matrix does not infer a clockface timetable or consolidate variants.

## Hub departure board

For the user-selected number of highest-activity candidate stop places, one record is generated for each relevant trip calling at that place. A trip/place pair is represented once.

## Gateway timetable

For each matched user-specified gateway, one record is generated for each active relevant trip calling there.

## Route geometry

Candidate route outputs use the published GTFS shape where available. If no usable source shape exists, a straight stop-sequence schematic may be generated and explicitly labelled `STOP_SEQUENCE_SCHEMATIC`.

The optional national map cache contains source `shapes.txt` geometry associated with routes; it is a browse layer and does not imply every route/shape is active on every date.

## QA measures

The JSON/report includes:
- candidate source-stop count;
- parent-station coverage among selected stops;
- GTFS-shape coverage among relevant trips;
- share of exact patterns used by only one active trip;
- unmatched user gateway terms;
- source cache filename.

## Comparability rule

Candidate comparisons are valid only when the GTFS release, reference-date methodology, candidate-construction rule and relevant profiler settings are held constant and recorded.

## Deliberately excluded

The toolkit does not calculate timetable friction, near misses, transfer quality, passenger demand, destination importance, accessibility benefit, commercial viability or R5 scenario effects.


## QGIS organisation and provenance

The project tree is presentation structure only and does not alter the analytical definitions. Candidate outputs are placed in fixed numbered groups so that source geography, summaries, timetables, external-connectivity evidence, contextual evidence and audit data remain distinct.

Each generated QGIS vector layer is assigned embedded metadata describing its subject area, source cache or evidence package, service date where applicable, analytical role, toolkit version, method and interpretation caveat. The same provenance is also written to `RuralTransport/*` custom layer properties so it persists with the QGIS project.

Symbology is deliberately descriptive. For example, route colours distinguish modes and hub styling distinguishes the activity-ranked top-N from other stop places; neither is a quality or priority score.


## Internal versus external supply

At a candidate stop place or route, an **external trip** is one that serves at least one stop outside the candidate as well as at least one candidate stop. An **internal trip** is an active relevant trip whose scheduled stops all remain inside the candidate. These counts describe the geographic role of provision; they are not a judgement about passenger purpose.

## Route gap

For each active trip on a route, the profiler takes the first scheduled candidate-area call. Successive first-call times are used to calculate route service gaps. This prevents a long route with many candidate stops from appearing artificially frequent because every stop call was counted as another service.

The profiler reports median gap and maximum gap within the analyst-defined daytime window.

## Hub gap

For activity-ranked stop places, successive scheduled trip calls are compared. Gaps above the user-set reporting threshold are exposed in `02.6 - Service Gaps`.

## Next alternative / consequence of missing a departure

Hub and gateway timetable rows include:

- next later departure on the same GTFS route; and
- next later departure to the same terminal destination.

The elapsed minutes provide a simple description of how consequential a missed departure may be. They do not assert that the later trip is operationally substitutable, accessible, affordable or appropriate for the same passenger.

## Gateway onward window

For each inbound external trip arriving at a matched gateway, the profiler finds the next different trip which departs that gateway and subsequently calls at another candidate stop place.

It reports whether this next candidate-serving departure is within 15, 30 or 60 minutes, together with median and maximum onward wait. This is a timetable-supply measure only; it does not account for walking time, reliability, guaranteed connections, ticket validity or passenger destination.

## Quarter-hour network timeline

For every 15-minute point within the selected daytime window, the profiler reports:

- scheduled trip spans active between their first and last candidate-area calls;
- distinct routes represented by those trip spans;
- distinct operators represented; and
- actual candidate stop calls occurring in the following 15 minutes.

`active_trip_spans` is not a vehicle-location estimate and must not be interpreted as realtime or simulated vehicle movement.

## Operator / feed coverage

The active candidate network is summarised by source agency/operator, with routes, trips, external trips, modes and service span. The analyst may optionally enter expected operator names. Exact normalised matches which are absent are reported as QA warnings.

This is intended to catch incomplete-feed problems before service conclusions are drawn; absence from the check does not prove an operator runs in the area unless the analyst supplied it as expected.

## Diagnostic signals

`02.7 - Diagnostic Signals` applies explicit lightweight rules to expose circumstances worth human review. Current signals include:

- service-pattern complexity;
- long daytime route gaps;
- routes whose candidate-serving trips are all external/through services;
- weak gateway onward windows;
- long gateway onward waits;
- missing expected operators; and
- potential pulse windows where at least three distinct routes call at a hub within 20 minutes.

Every signal carries its evidence, review prompt and rule. Signals are not recommendations, scores or evidence of passenger demand.

## Quantified candidate baseline (v8.4)

The quantified baseline joins the current spatial-evidence profile to the date-specific network-summary JSON.
It is intended for candidate comparison before feasibility work. It does not create a composite ranking.

The output separates:
- **raw/comparable measures**: population, households, density, historical access indicators, scheduled network
  counts, service span, route-direction gaps, pattern structure, external connectivity, gateway connection windows,
  timetable activity by daypart and source-data QA; and
- **evidence gaps**: measures that cannot be supported by the supplied package, such as route patronage, visitor
  demand, supported-service share, contract windows, local delivery capacity, fares/ticketing integration,
  operational reliability and marginal cost.

Derived timetable-activity measures use the existing quarter-hour `active_trip_span` definition. They are useful
for describing how peaky the scheduled network is, but they are not peak vehicle requirement, fleet utilisation
or vehicle-location estimates.

Gateway connection percentages use individual inbound external arrivals from `gateway_connection_context` and
therefore avoid averaging percentages across gateways. They remain timetable-supply measures and do not account
for reliability, walking time, accessibility, ticket validity or guaranteed connections.

Cross-candidate comparison should use the same GTFS release, service-date convention, candidate-boundary method,
spatial evidence package and profiler settings.
