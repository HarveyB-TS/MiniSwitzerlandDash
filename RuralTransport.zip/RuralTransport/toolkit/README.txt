RURAL TRANSPORT QGIS TOOLKIT v8.4 — QUANTIFIED CANDIDATE BASELINE
===================================================

Designed for QGIS 4.x and the large Scottish GTFS feed used during development.
The analytical rules are deliberately conservative: the toolkit describes scheduled
network supply and structure without deciding whether it is good, bad or sufficient.

INSTALL
-------
1. Unzip this package.
2. In QGIS open Processing > Toolbox > Scripts > Add Script to Toolbox, or copy the
   .py files into the active profile's processing/scripts folder.
3. Add/retain these scripts:
   - build_gtfs_cache.py
   - rural_candidate_profile.py
   - explore_candidate_gtfs_cached.py
   - profile_candidate_network.py
   - quantified_candidate_baseline.py
4. Refresh Processing Scripts or restart QGIS.

RECOMMENDED WORKFLOW
--------------------
1. BUILD THE NATIONAL CACHE ONCE
   Run "1 - Build indexed GTFS cache" for each GTFS release.

   The output SQLite cache retains the source GTFS tables and adds indexes.
   By default v8.2 also builds a companion *_map.gpkg containing:
   - GTFS stops
   - published GTFS route/shape geometry

   The map cache is optional and a failure to build it does not invalidate the indexed
   timetable cache.

2. DRAW / SELECT A STUDY AREA
   The polygon defines the analytical focus. It does not define where the transport
   network ends.

3. SOURCE-LEVEL NETWORK EXPLORATION
   Run "2 - Explore GTFS services serving candidate".

   This produces a fixed, numbered project tree:
   00 - Candidate Overview
     00.1 - GTFS Candidate Summary
   01 - Network Geography
     01.1 - Stops Serving Study Area
     01.2 - Routes on Map
     01.3 - Exact Service Patterns
   09 - Audit / Source Data
     09.1 - Scheduled Calls

4. PRE-REFINED NETWORK PROFILE AND TIMETABLES
   Run "3 - Profile candidate network and timetables" using the same polygon/date.

   This adds:
   02 - Network Summary
     02.1 - Stop Places & Hubs
     02.2 - Route Summary
     02.3 - Operators / Feed Coverage
     02.4 - Hourly Service Profile
     02.5 - Quarter-hour Network Timeline
     02.6 - Service Gaps
     02.7 - Diagnostic Signals

   03 - Timetables
     03.1 - Hub Departure Boards
     03.2 - Gateway Timetables (when gateways are specified)
     03.3 - Route Timetable Matrices

   04 - External Connectivity
     04.1 - Direct External Destinations
     04.2 - External / Feeder Services
     04.3 - Gateway Summary (when gateways are specified)

   It also writes:
     <candidate>_<date>_network_summary.json
     <candidate>_<date>_network_report.html

   The HTML report contains human-readable route timetable matrices and can be opened
   directly in a browser. The JSON is designed for onward analysis/review without
   requiring the full GeoPackage or millions of stop-time rows.



WHAT v8.2 ADDS FOR NETWORK-DESIGN ANALYSIS
------------------------------------------
The profiler now surfaces several measures which previously had to be inferred manually:

- internal versus external trips at routes and hubs;
- median and maximum daytime service gaps;
- quarter-hour network activity through the selected day;
- next same-route and same-destination departure after each hub/gateway call;
- gateway inbound external arrivals and the number with onward candidate-serving service
  within 15, 30 and 60 minutes;
- median and maximum onward waits at gateways;
- operator/feed inventory plus an optional expected-operator completeness check;
- transparent diagnostic signals for service-pattern complexity, long gaps, weak gateway
  onward windows, entirely external routes and naturally clustered pulse windows.

Diagnostic signals are prompts for analyst review, not recommendations, priorities or scores.
They deliberately expose their rule and evidence so the analyst can accept, reject or reinterpret
what they mean in the local context.

For candidate comparison, use the same service-date convention, daytime window and gap threshold.
For service design, inspect the underlying timetable, route and trip IDs before recommending changes.

5. DEMOGRAPHIC / ACCESS EVIDENCE
   Run "4 - Generate rural transport evidence profile" against the evidence GeoPackage.

6. QUANTIFIED CANDIDATE BASELINE
   Run "5 - Generate quantified candidate baseline" using:
   - the one-row spatial evidence profile from Step 4; and
   - the network-summary JSON written by Step 3.

   This produces a new project group:
   06 - Candidate Comparison
     06.1 - Quantified Candidate Baseline
     06.2 - Quantified Metric Register
     06.3 - Evidence Gaps

   It also writes CSV, JSON and HTML files designed to be lined up across candidate areas.
   The output includes only measures supported by the current evidence: population/households, historical
   access indicators, present-day scheduled network supply, service gaps, gateway connection windows,
   operator/mode mix and timetable activity. Measures such as patronage, car ownership, OD flows,
   contract leverage, fares/ticketing integration and cost are listed explicitly as evidence gaps unless
   supplied by a future evidence-pack extension.


QGIS PROJECT ORGANISATION
-------------------------
Candidate outputs use one parent group named after the Subject Area, with a stable tree:

  00 - Candidate Overview
  01 - Network Geography
  02 - Network Summary
  03 - Timetables
  04 - External Connectivity
  05 - Evidence Context
  06 - Candidate Comparison
  09 - Audit / Source Data

Layers are numbered within each group so repeated runs are easy to inspect. Dense source/audit
layers (exact patterns, scheduled calls, contributing Data Zones and co-located departure-board
points) load switched off where appropriate. The principal network layers load visible.

Generated vector layers receive:
- human-readable field aliases;
- a useful display expression where applicable;
- restrained default QGIS symbology;
- QGIS layer metadata (identifier, title, abstract, category, keywords and lineage); and
- RuralTransport/* custom properties recording subject, source, service date, method, version,
  output role and analytical caveat.

The national GTFS source group is kept separately under `GTFS - <feed name>` with:
  01 - Published Network Geography
  09 - Source Registers

USER-DEFINED GATEWAYS
---------------------
The network profiler accepts an optional semicolon-separated list, for example:

  Uig Pier; Sconser Ferry Terminal; Armadale Pier

Gateway matching is deliberately conservative:
- exact GTFS stop/place name after normalising case/punctuation, OR
- exact GTFS stop_id / parent_station ID.

No fuzzy geographic or name inference is performed. Unmatched gateway terms are
reported in QA.

STOP PLACES / HUBS
------------------
For summary purposes, stops are grouped using GTFS parent_station where supplied.
Where no parent_station is supplied, the source stop_id remains its own stop place.

The "top hubs" are simply the N stop places with the highest number of unique active
trips on the selected date. This is an activity ranking, not a strategic importance
or quality score. N is user configurable.

EXTERNAL / FEEDER SERVICES
--------------------------
An external trip is an active trip which:
- calls at >=1 stop inside the candidate; and
- calls at >=1 stop outside the candidate.

The profiler records whether the trip arrives from outside and/or departs to outside.
It reports the median gap between outward services and the largest gap within the
user-set daytime window. Unique trips are counted, not every stop call.

DIRECT DESTINATIONS
-------------------
A direct external destination is a stop place outside the candidate which is scheduled
after at least one candidate stop on an active relevant trip. No interchange is assumed.

SERVICE-PATTERN COMPLEXITY
--------------------------
Patterns are exact combinations of:
  route_id + direction_id + ordered stop_id sequence

The route summary reports:
- number of patterns
- number of active trips
- dominant pattern share
- number of single-trip patterns

These describe timetable structure only. They are not treated as a quality score.

TIMETABLES
----------
Route timetable matrices use the exact GTFS service pattern. Trips are columns and
stops are rows. The QGIS table provides the same timetable in a compact row format;
the HTML report provides the more conventional matrix view.

Hub departure boards are produced for the N busiest stop places, ranked by unique
active trips. Gateway timetables are produced only for gateways explicitly specified
by the user.

COMPARABILITY
-------------
For like-for-like candidate comparison hold constant:
- GTFS feed/version
- selected service date rule
- candidate polygon methodology
- stop buffer
- daytime gap window
- hub top-N setting where hub outputs are compared

Do not compare arbitrary dates or different timetable releases without recording it.

DELIBERATELY NOT INCLUDED
-------------------------
- near-miss scoring
- transfer-quality scoring
- automatic "opportunity" scoring
- inferred important destinations
- automatic route consolidation
- demand modelling
- R5 accessibility effects
- timetable optimisation

Those can be separate analytical stages. v8.2's role is to pre-refine the source GTFS
into evidence that an analyst can inspect and interpret.
