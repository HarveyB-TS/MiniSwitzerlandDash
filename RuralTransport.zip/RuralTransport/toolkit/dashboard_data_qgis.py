"""QGIS Processing entry point for the v8.6 dashboard export extension."""
import subprocess,sys
from qgis.core import QgsProcessingAlgorithm,QgsProcessingParameterFile,QgsProcessingParameterString,QgsProcessingException,QgsProcessingOutputString
class ExportDashboardData(QgsProcessingAlgorithm):
 def name(self):return 'export_dashboard_data'
 def displayName(self):return '6 - Export client dashboard tables [v8.6 extension]'
 def group(self):return 'Rural Transport Integration'
 def groupId(self):return 'rural_transport_integration'
 def createInstance(self):return ExportDashboardData()
 def initAlgorithm(self,config=None):
  self.addParameter(QgsProcessingParameterFile('CONFIG','Dashboard project.json',extension='json'))
  self.addParameter(QgsProcessingParameterFile('SCRIPT','refresh.py',extension='py'))
  self.addParameter(QgsProcessingParameterString('PYTHON','Python executable with handover requirements',defaultValue=sys.executable))
  self.addOutput(QgsProcessingOutputString('LOG','Export log'))
 def processAlgorithm(self,p,context,feedback):
  cmd=[self.parameterAsString(p,'PYTHON',context),self.parameterAsFile(p,'SCRIPT',context),'--config',self.parameterAsFile(p,'CONFIG',context)]
  result=subprocess.run(cmd,text=True,capture_output=True)
  feedback.pushInfo(result.stdout)
  if result.returncode:raise QgsProcessingException(result.stderr or result.stdout)
  return {'LOG':result.stdout}
