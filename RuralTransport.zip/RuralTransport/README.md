# Rural transport candidate dashboard

This handover contains the seven supplied study areas, cleaned analytical tables, a Power BI Project and the QGIS processing workflow. The timetable reference date is Monday 12 October 2026. Census observations refer to 2022.

Start with `report/RuralCandidates.pbip`. Keep its Report and SemanticModel folders together. The model has twelve tables and uses local CSV imports. There are five pages: candidate comparison, network and gateways, Census travel markets, supported bus services, and study-area detail.

**A Windows Power BI Desktop check is still required.** The project and model have passed structural checks. Desktop opening, CSV refresh, visual rendering and interaction tests have not been run on this Mac. No compiled PBIX is supplied. Follow `docs/POWER_BI_FINALISATION.md` before sending a final PBIX to the client.

## Files to hand over

- `report/`: editable PBIP, PBIR report and TMDL model.
- `data/`: cleaned CSVs, a SQLite copy, geography, source hashes and quality notes. These are sufficient to refresh Power BI without QGIS.
- `docs/`: definitions, methods, validation evidence and Desktop completion steps.
- `qgis_outputs/Candidate_analysis.qgz`: mapped routes, stops and gateways; full candidate-serving routes extend beyond the area boundaries.
- `config/`, `scripts/`, `toolkit/`, `inputs/`: reproducible pipeline and supplied sources. The large national timetable cache and source feed are needed only for network regeneration.

The supplied toolkit was v8.4. Its original cache builder and network profiler were reused. The brief's v8.5 archive was unavailable. The new demographic, subsidy and dashboard processing modules extend those available calculations.

## Package choices

`RuralTransport_Client_Report_and_Tables.zip` contains the report, cleaned tables, QGIS outputs and guidance. It can refresh Power BI from those tables. `RuralTransport_Full_Rebuild_Handover.zip` also includes national timetable, Census, rurality and evidence inputs for regenerating the analysis. Use the full package to run the Python refresh workflow.

## Quick use

1. Extract to a short folder such as `C:\RuralTransport`.
2. Open `report\RuralCandidates.pbip` in current Power BI Desktop with PBIP support enabled.
3. Set the `DataFolder` Power Query parameter to your extracted `data` folder, with a trailing slash or backslash.
4. Refresh, then complete the checks in `docs/POWER_BI_FINALISATION.md`.
5. Save as PBIX when those checks pass. Keep the PBIP and cleaned tables as the editable source.

## Refresh the underlying tables

Use Python 3.11 or later:

```sh
python -m venv .venv
# Activate the environment using the command for your operating system.
python -m pip install -r requirements.txt
python scripts/refresh.py
python scripts/validate_data.py
```

This imports the existing QGIS network profiles and rebuilds demographic, OD, subsidy, context and audit tables. To change a date or boundary, regenerate the network profiles too:

```sh
python scripts/refresh.py --network --qgis-python "/path/to/QGIS/python"
python scripts/validate_data.py
```

Use the Python interpreter supplied with your QGIS installation, with its QGIS environment configured. Ordinary system Python cannot replace it for network processing. See `docs/REFRESH_AND_QGIS.md`.

## Interpretation

These are exploratory analytical envelopes. Partial Census zones are allocated using documented estimates. Scheduled trips describe timetable supply. Census OD counts describe observed movements in 2022. Neither is a patronage forecast. Gateway windows use the original profiler's same-place timetable method, with walking transfers unmodelled. Subsidy status comes from inferred registration matches and contains no expenditure data. Unknown remains a separate category.

R5 is deferred. Accessibility and scenario result tables have an import contract but contain no fabricated results. Historical SIMD and SABI records and rurality are exported separately, keeping the primary Power BI model simple.

A worthwhile next step is to compare tighter settlement-led boundaries with the supplied envelopes, especially SE Loch Lomond and Trossachs. Report how much of each population estimate comes from partial zones before drawing conclusions from population-normalised supply.
