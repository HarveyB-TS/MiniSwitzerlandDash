# Data dictionary

CSV files use UTF-8, comma separators and a header. Blank numeric fields mean unavailable. Zero means a numeric zero. Counts allocated from partial zones retain decimal values. `data/schemas.json` is the machine-readable type contract. `dashboard_tables.sqlite` contains the same exported tables.

The primary Power BI model contains twelve tables. Extra source, geography and audit exports stay outside that model. Model relationships use single-direction filters from dimensions to facts. Area, date, route and indicator are the conformed keys.

## dim_candidate_area

Rows: 7. Grain: See data dictionary. Primary Power BI model: yes.

| Column | Type | Meaning |
|---|---|---|
| area_id | string | Stable study-area key; candidate_01 to candidate_07. Blank denotes project-wide evidence notes. |
| area_name | string | Area name. See methodology and original source definitions. |
| geography | string | Geography. See methodology and original source definitions. |
| selection_basis | string | Selection basis. See methodology and original source definitions. |
| area_km2 | number | Area km2. See methodology and original source definitions. |
| external_context | string | External context. See methodology and original source definitions. |
| boundary_method | string | Boundary method. See methodology and original source definitions. |
| population | number | Population. See methodology and original source definitions. |
| latitude | number | Representative point latitude, WGS84. |
| longitude | number | Representative point longitude, WGS84. |

## dim_date

Rows: 1. Grain: See data dictionary. Primary Power BI model: yes.

| Column | Type | Meaning |
|---|---|---|
| date_id | string | Timetable/reporting date, ISO YYYY-MM-DD; Census source period remains separate. |
| year | integer | Year. See methodology and original source definitions. |
| month | integer | Month. See methodology and original source definitions. |
| day | integer | Day. See methodology and original source definitions. |
| day_name | string | Day name. See methodology and original source definitions. |

## fact_population

Rows: 7. Grain: area × reporting date; source period 2022. Primary Power BI model: yes.

| Column | Type | Meaning |
|---|---|---|
| area_id | string | Stable study-area key; candidate_01 to candidate_07. Blank denotes project-wide evidence notes. |
| date_id | string | Timetable/reporting date, ISO YYYY-MM-DD; Census source period remains separate. |
| source_period | string | Observation/reference period; distinguish from the analysis date. |
| geography | string | Geography. See methodology and original source definitions. |
| population | number | Population. See methodology and original source definitions. |
| households | number | Households. See methodology and original source definitions. |
| households_no_car | number | Households no car. See methodology and original source definitions. |
| no_car_pct | number | 100 × no-car households / occupied households. CSV percentage points; BI percentage measure is a ratio. |
| workplace_population | number | Workplace population. See methodology and original source definitions. |
| daytime_population | number | Daytime population. See methodology and original source definitions. |
| allocation_method | string | Whole-zone count or stated overlap estimate. |
| source_id | string | SHA-256 prefix; look up the full source hash in source_manifest. |

## fact_od_flows

Rows: 58,223. Grain: area × purpose × series × origin × destination × mode. Primary Power BI model: yes.

| Column | Type | Meaning |
|---|---|---|
| area_id | string | Stable study-area key; candidate_01 to candidate_07. Blank denotes project-wide evidence notes. |
| date_id | string | Timetable/reporting date, ISO YYYY-MM-DD; Census source period remains separate. |
| purpose | string | Work or Study. |
| series | string | corridor_total or mode_detail; never add these views together. |
| geography | string | Geography. See methodology and original source definitions. |
| origin_code | string | Origin code. See methodology and original source definitions. |
| origin_name | string | Origin name. See methodology and original source definitions. |
| destination_code | string | Destination code. See methodology and original source definitions. |
| destination_name | string | Destination name. See methodology and original source definitions. |
| mode | string | Mode. See methodology and original source definitions. |
| people | number | Published/allocated Census count, not forecast patronage. |
| allocation_method | string | Whole-zone count or stated overlap estimate. |
| source_period | string | Observation/reference period; distinguish from the analysis date. |
| source_id | string | SHA-256 prefix; look up the full source hash in source_manifest. |

## fact_network_supply

Rows: 156. Grain: area × date × GTFS route. Primary Power BI model: yes.

| Column | Type | Meaning |
|---|---|---|
| area_id | string | Stable study-area key; candidate_01 to candidate_07. Blank denotes project-wide evidence notes. |
| date_id | string | Timetable/reporting date, ISO YYYY-MM-DD; Census source period remains separate. |
| route_id | string | Route id. See methodology and original source definitions. |
| route_number | string | Route number. See methodology and original source definitions. |
| route_name | string | Route name. See methodology and original source definitions. |
| agency_id | string | Agency id. See methodology and original source definitions. |
| operator | string | Operator. See methodology and original source definitions. |
| mode | string | Mode. See methodology and original source definitions. |
| scheduled_trips | integer | Active scheduled candidate-serving trips on the reference day, not passengers. |
| service_span_min | number | Service span min. See methodology and original source definitions. |
| median_gap_min | number | Median gap min. See methodology and original source definitions. |
| max_day_gap_min | number | Max day gap min. See methodology and original source definitions. |
| first_call | string | First call. See methodology and original source definitions. |
| last_call | string | Last call. See methodology and original source definitions. |
| feed_version | string | Source feed version identifier from feed_info. |
| source_id | string | SHA-256 prefix; look up the full source hash in source_manifest. |

## fact_gateway_connections

Rows: 28. Grain: area × date × gateway. Primary Power BI model: yes.

| Column | Type | Meaning |
|---|---|---|
| area_id | string | Stable study-area key; candidate_01 to candidate_07. Blank denotes project-wide evidence notes. |
| date_id | string | Timetable/reporting date, ISO YYYY-MM-DD; Census source period remains separate. |
| gateway_id | string | Gateway id. See methodology and original source definitions. |
| gateway_name | string | Gateway name. See methodology and original source definitions. |
| external_arrivals | integer | Original profiler inbound external arrivals at the selected stop/place. |
| onward_15 | integer | Arrivals with a different onward trip within 15 minutes under the profiler method. |
| onward_30 | integer | Equivalent count within 30 minutes. |
| onward_60 | integer | Equivalent count within 60 minutes. |
| median_wait_min | number | Median wait min. See methodology and original source definitions. |
| max_wait_min | number | Max wait min. See methodology and original source definitions. |
| feed_version | string | Source feed version identifier from feed_info. |
| source_id | string | SHA-256 prefix; look up the full source hash in source_manifest. |

## fact_network_hourly

Rows: 210. Grain: See data dictionary. Primary Power BI model: yes.

| Column | Type | Meaning |
|---|---|---|
| area_id | string | Stable study-area key; candidate_01 to candidate_07. Blank denotes project-wide evidence notes. |
| date_id | string | Timetable/reporting date, ISO YYYY-MM-DD; Census source period remains separate. |
| hour | integer | Hour. See methodology and original source definitions. |
| unique_trips | integer | Unique trips active within each hour; trips can recur in later hours. |
| candidate_calls | integer | Candidate stop calls in the hour. |
| source_id | string | SHA-256 prefix; look up the full source hash in source_manifest. |

## fact_subsidy_services

Rows: 122. Grain: area × date × GTFS bus route; service_key may repeat across GTFS routes. Primary Power BI model: yes.

| Column | Type | Meaning |
|---|---|---|
| area_id | string | Stable study-area key; candidate_01 to candidate_07. Blank denotes project-wide evidence notes. |
| date_id | string | Timetable/reporting date, ISO YYYY-MM-DD; Census source period remains separate. |
| route_id | string | Route id. See methodology and original source definitions. |
| route_number | string | Route number. See methodology and original source definitions. |
| operator | string | Operator. See methodology and original source definitions. |
| category | string | Category. See methodology and original source definitions. |
| scheduled_trips | integer | Active scheduled candidate-serving trips on the reference day, not passengers. |
| service_records | integer | Service records. See methodology and original source definitions. |
| funder | string | Funder. See methodology and original source definitions. |
| funding_basis | string | Preserves observed or assumed provenance for funder. |
| registration_confidence | string | Registration confidence. See methodology and original source definitions. |
| registration_match_status | string | Registration match status. See methodology and original source definitions. |
| gtfs_match_status | string | Exact, ambiguous, unmatched or out-of-date source match outcome. |
| record_ids | string | Source subsidy row identifiers retained for audit. |
| start_date | string | Start date. See methodology and original source definitions. |
| end_date | string | End date. See methodology and original source definitions. |
| source_id | string | SHA-256 prefix; look up the full source hash in source_manifest. |
| service_key | string | Deduplicated source service identifier for service-record denominators. |
| registration_active | string | Registration active. See methodology and original source definitions. |
| registration_ambiguous | string | Registration ambiguous. See methodology and original source definitions. |
| registration_number | string | Registration number. See methodology and original source definitions. |

## subsidy_match_audit

Rows: 1,550. Grain: See data dictionary. Primary Power BI model: no.

| Column | Type | Meaning |
|---|---|---|
| record_id | string | Record id. See methodology and original source definitions. |
| route_id | string | Route id. See methodology and original source definitions. |
| category | string | Category. See methodology and original source definitions. |
| match_status | string | Match status. See methodology and original source definitions. |
| reason | string | Reason. See methodology and original source definitions. |
| source_id | string | SHA-256 prefix; look up the full source hash in source_manifest. |

## fact_accessibility

Rows: 0. Grain: See data dictionary. Primary Power BI model: no.

| Column | Type | Meaning |
|---|---|---|
| area_id | string | Stable study-area key; candidate_01 to candidate_07. Blank denotes project-wide evidence notes. |
| date_id | string | Timetable/reporting date, ISO YYYY-MM-DD; Census source period remains separate. |
| scenario_id | string | Scenario id. See methodology and original source definitions. |
| scenario_type | string | baseline or scenario; optional future R5 input. |
| metric_id | string | Metric id. See methodology and original source definitions. |
| value | number | Value. See methodology and original source definitions. |
| unit | string | Unit. See methodology and original source definitions. |
| origin_definition | string | Origin definition. See methodology and original source definitions. |
| departure_window | string | Departure window. See methodology and original source definitions. |
| travel_time_limit_min | number | Travel time limit min. See methodology and original source definitions. |
| journey_criteria | string | Journey criteria. See methodology and original source definitions. |
| source_id | string | SHA-256 prefix; look up the full source hash in source_manifest. |

## fact_area_metrics

Rows: 63. Grain: area × date × metric. Primary Power BI model: yes.

| Column | Type | Meaning |
|---|---|---|
| area_id | string | Stable study-area key; candidate_01 to candidate_07. Blank denotes project-wide evidence notes. |
| date_id | string | Timetable/reporting date, ISO YYYY-MM-DD; Census source period remains separate. |
| metric_id | string | Metric id. See methodology and original source definitions. |
| value | number | Value. See methodology and original source definitions. |
| unit | string | Unit. See methodology and original source definitions. |
| denominator | string | Denominator. See methodology and original source definitions. |
| source_period | string | Observation/reference period; distinguish from the analysis date. |
| source_id | string | SHA-256 prefix; look up the full source hash in source_manifest. |

## dim_indicator

Rows: 9. Grain: See data dictionary. Primary Power BI model: yes.

| Column | Type | Meaning |
|---|---|---|
| metric_id | string | Metric id. See methodology and original source definitions. |
| label | string | Label. See methodology and original source definitions. |
| unit | string | Unit. See methodology and original source definitions. |
| definition | string | Definition. See methodology and original source definitions. |
| denominator | string | Denominator. See methodology and original source definitions. |
| interpretation | string | Interpretation. See methodology and original source definitions. |

## data_quality

Rows: 70. Grain: See data dictionary. Primary Power BI model: yes.

| Column | Type | Meaning |
|---|---|---|
| area_id | string | Stable study-area key; candidate_01 to candidate_07. Blank denotes project-wide evidence notes. |
| date_id | string | Timetable/reporting date, ISO YYYY-MM-DD; Census source period remains separate. |
| severity | string | Severity. See methodology and original source definitions. |
| code | string | Code. See methodology and original source definitions. |
| dataset | string | Dataset. See methodology and original source definitions. |
| detail | string | Detail. See methodology and original source definitions. |

## source_manifest

Rows: 22. Grain: See data dictionary. Primary Power BI model: no.

| Column | Type | Meaning |
|---|---|---|
| source_id | string | SHA-256 prefix; look up the full source hash in source_manifest. |
| file_name | string | File name. See methodology and original source definitions. |
| sha256 | string | Sha256. See methodology and original source definitions. |
| source_period | string | Observation/reference period; distinguish from the analysis date. |
| analysis_date | string | Analysis date. See methodology and original source definitions. |

## dim_route

Rows: 143. Grain: See data dictionary. Primary Power BI model: yes.

| Column | Type | Meaning |
|---|---|---|
| route_id | string | Route id. See methodology and original source definitions. |
| route_number | string | Route number. See methodology and original source definitions. |
| route_name | string | Route name. See methodology and original source definitions. |
| agency_id | string | Agency id. See methodology and original source definitions. |
| operator | string | Operator. See methodology and original source definitions. |
| mode | string | Mode. See methodology and original source definitions. |
| latitude | number | Representative point latitude, WGS84. |
| longitude | number | Representative point longitude, WGS84. |

## dim_gateway

Rows: 4. Grain: See data dictionary. Primary Power BI model: no.

| Column | Type | Meaning |
|---|---|---|
| gateway_id | string | Gateway id. See methodology and original source definitions. |
| gateway_name | string | Gateway name. See methodology and original source definitions. |
| latitude | number | Representative point latitude, WGS84. |
| longitude | number | Representative point longitude, WGS84. |

## fact_gateway_arrivals

Rows: 16. Grain: See data dictionary. Primary Power BI model: no.

| Column | Type | Meaning |
|---|---|---|
| area_id | string | Stable study-area key; candidate_01 to candidate_07. Blank denotes project-wide evidence notes. |
| date_id | string | Timetable/reporting date, ISO YYYY-MM-DD; Census source period remains separate. |
| gateway_id | string | Gateway id. See methodology and original source definitions. |
| incoming_trip_id | string | Incoming trip id. See methodology and original source definitions. |
| arrival_time | string | Arrival time. See methodology and original source definitions. |
| next_onward_trip_id | string | Next onward trip id. See methodology and original source definitions. |
| next_onward_time | string | Next onward time. See methodology and original source definitions. |
| wait_minutes | number | Wait minutes. See methodology and original source definitions. |
| source_id | string | SHA-256 prefix; look up the full source hash in source_manifest. |

## area_rurality_context

Rows: 27. Grain: See data dictionary. Primary Power BI model: no.

| Column | Type | Meaning |
|---|---|---|
| area_id | string | Stable study-area key; candidate_01 to candidate_07. Blank denotes project-wide evidence notes. |
| classification | string | Classification. See methodology and original source definitions. |
| class_name | string | Class name. See methodology and original source definitions. |
| overlap_km2 | number | Overlap km2. See methodology and original source definitions. |
| classified_land_share_pct | number | Share of intersected classified land area, not resident population. |
| source_period | string | Observation/reference period; distinguish from the analysis date. |
| source_id | string | SHA-256 prefix; look up the full source hash in source_manifest. |

## historical_zone_context

Rows: 334. Grain: See data dictionary. Primary Power BI model: no.

| Column | Type | Meaning |
|---|---|---|
| area_id | string | Stable study-area key; candidate_01 to candidate_07. Blank denotes project-wide evidence notes. |
| dz2011 | string | Dz2011. See methodology and original source definitions. |
| overlap_fraction | number | Intersection area / original 2011 zone area; no direct 2022 ID join. |
| simd16_pt_gp | number | Simd16 pt gp. See methodology and original source definitions. |
| simd16_access_rank | number | Historical zone rank. Do not average ranks. |
| simd20_access_decile | number | Historical zone decile. Do not treat as current 2022 access. |
| sabi_weekday_2019 | number | Historical weekday SABI value on 2011 zones. |
| sabi_weekend_2019 | number | Historical weekend SABI value on 2011 zones. |
| source_note | string | Source note. See methodology and original source definitions. |
| source_id | string | SHA-256 prefix; look up the full source hash in source_manifest. |

## dim_display

Rows: 2. Grain: See data dictionary. Primary Power BI model: no.

| Column | Type | Meaning |
|---|---|---|
| display_mode | string | Display mode. See methodology and original source definitions. |

## Headline indicator definitions

| Indicator | Unit | Denominator | Definition |
|---|---|---|---|
| Resident population | people | people | 2022 resident population aggregated over candidate Data Zones. Partial zones use area overlap. |
| Households without a car | % | occupied households | No-car households divided by occupied households from Census UV405. |
| Scheduled trips | trips | scheduled trips | Sum of active candidate-serving GTFS trips across routes on the reference date. |
| Scheduled trips per 1,000 residents | trips / 1,000 people | 2022 estimated residents | Scheduled candidate-serving trips divided by estimated resident population, multiplied by 1,000. |
| Routes | routes | GTFS route IDs | Distinct GTFS route IDs serving the area on the reference date. |
| Supported bus trip share | % | all scheduled bus trips | Subsidised plus partly subsidised scheduled bus trips divided by all scheduled bus trips, including Unknown. |
| Unknown bus trip share | % | all scheduled bus trips | Scheduled bus trips without resolved subsidy category divided by all scheduled bus trips. |
| Observed work OD flow | people | Table 5a counts | Sum of Table 5a residence-to-work counts for candidate origins. |
| Observed study OD flow | people | Table 8a counts | Sum of Table 8a residence-to-study counts for candidate origins. |

## Supporting files

area_zone_allocation.csv exposes the 2022 Data Zone weights. candidate_areas.geojson contains the normalised polygons and metadata. route_lines_simplified.geojson contains area/route identifiers and simplified full route lines. The source candidate and gateway geometries are preserved under inputs/study_areas.

The date dimension currently contains one comparison date. Historical periods are attributes rather than extra rows in the current-date comparison. No time intelligence or annual demand comparison is implied.
