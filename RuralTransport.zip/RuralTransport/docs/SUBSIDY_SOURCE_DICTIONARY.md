# route_subsidy.csv — data dictionary

**File:** `route_subsidy.csv` (1,550 rows)
**Built by:** `registration_subsidy/regsubsidy/route_subsidy.py` from
`registration_subsidy/output_phase3/service_subsidy_dataset.csv`
**Generated:** see `registration_subsidy/output_phase3/qa_summary.json` and `source_manifest.json`

## What it is

One row per **service** = (National Operator Code, line name), for the Scottish
TransXChange (TNDS) export. It records whether the service matches a Traffic
Commissioner (VOSA) bus registration and, where it does, the **subsidy status**
and **funder**.

**Scope:** Scotland, TNDS `S.zip` (2,405 XML files → 1,460 bus + 90 ferry/coach/rail
services). **Not** Great Britain-wide.

**Subsidy is inferred** from the matched registration, not stated by the
timetable. `Unknown` means *no registration matched* — it does **not** mean "not
subsidised".

## Key columns

### Identity / source
| Column | Meaning |
|---|---|
| `operator_code` | National Operator Code (NOC) |
| `operator_name` | operator name(s) as printed in the TXC |
| `route` | line name(s) |
| `description` | `origin - destination` |
| `mode` | `bus` / `ferry` / `coach` / `rail` (absent TXC mode → `bus`) |
| `council_service` | `Council Service` when the operator is a local authority (or a `CB…/SB…` registration regime); else blank |
| `service_codes` | TXC `<ServiceCode>` value(s) |
| `txc_licences` | licence number(s) as printed in the TXC |
| `origin`, `destination` | route endpoints from the TXC |
| `txc_start_date`, `txc_end_date` | operating window from the TXC |
| `num_files` | number of TXC files collapsed into this row |

### Matching
| Column | Meaning |
|---|---|
| `match_status` | `matched` / `unmatched` |
| `confidence` | `high` / `medium` / `low` / `none` |
| `match_method` | `licence+line`, `licence+line(historical)`, `licence+line(base)`, `operator-group`, `operator+line` |
| `match_key` | the licence/operator + token that produced the match |
| `n_candidates` | number of candidate registrations considered |
| `ambiguous` | `True` if more than one candidate was equally plausible |
| `candidate_registrations` | all candidate registration numbers (`;`-separated) |
| `unmatch_reason` | why no registration matched (blank when matched) |

`confidence`: **high** = exact current service number under the same licence and
the registration is live/active; **medium** = base-number match, historical
token, or an inactive registration; **low** = operator-name match or base with an
inactive registration; **none** = unmatched.

### Chosen registration
| Column | Meaning |
|---|---|
| `registration_number` | VOSA registration, e.g. `PM1037871/100` |
| `registration_licence` | operator licence of that registration |
| `registration_operator` | operator name on the registration |
| `registration_service_number` | service number on the registration (latest variation) |
| `registration_status` | `Registered` / `Cancelled` / `Expired` / `Withdrawn` / … |
| `registration_active` | status ∈ {New, Registered, Variation} |
| `registration_is_live` | present in the current-registrations extract |
| `registration_variation_number` | latest variation number |
| `registration_effective_date`, `registration_received_date`, `registration_end_date` | dates of the latest variation |
| `registration_authority` | authority named on the registration (`Auth_Description`) |
| `registration_scheme` | `psv_licence` or `registration_reference` |
| `external_registration_reference` | non-PSV `CB…/SB…` reference (from Notices & Proceedings); blank otherwise |

### Subsidy
| Column | Meaning |
|---|---|
| `subsidies_description` | observed wording: `Yes` / `No` / `In Part` |
| `subsidies_details` | funder as recorded on the registration (observed) |
| `subsidy_category` | `Subsidised` / `Partly subsidised` / `Not subsidised` / `Unknown` |
| `subsidised_any` | `Yes` / `No` / `Unknown` |
| `subsidy_funder` | who pays |
| `subsidy_funder_source` | `VOSA registration` (observed) · `council in-house (assumed)` · blank |

`subsidy_funder` is the observed funder where the registration carries subsidy
wording. For council in-house services (no such wording exists) it is the council
itself, flagged `council in-house (assumed)` — an assumption, not an observation.

## Coverage (bus)

| | routes | % |
|---|---:|---:|
| Subsidised (`Yes`) | 445 | 30.5% |
| Partly subsidised (`In Part`) | 83 | 5.7% |
| Not subsidised (`No`) | 721 | 49.4% |
| **Unknown** | **211** | **14.5%** |

- Subsidy resolved for **1,249 / 1,460 (85.5%)** bus routes.
- Funder **observed** for 573; **assumed** for 88 council routes; blank for 799.
- 88 routes carry the `Council Service` tag; all are `Unknown` subsidy (the
  non-PSV regime carries no subsidy wording).

## Limitations — read before use

1. **Inferred, not authoritative.** The TXC does not name its registration; the
   link is derived from licence + line (plus operator group / name), with
   confidence tiers.
2. **14.5% of bus routes are `Unknown`** for structural reasons: 86 licence not
   in the VOSA exports, 79 service number not registered under the licence, 46
   placeholder licence. These are not missing work — the registration simply
   isn't in the public data.
3. **Council services have no observed subsidy.** Their funder is assumed.
4. **Scope is Scotland/TNDS only**, and only services present in that export.
5. **Match may be wrong** for medium/low confidence rows (flagged). 171 matched
   rows point at an inactive registration.

## Provenance / reproduce

Sources (hashed in `registration_subsidy/output_phase3/source_manifest.json`):
TransXChange `S.zip`; Traffic Commissioner registration extracts (8 areas × 2
files); Traveline NOC record; DVSA operator-licence records (Scotland); Scotland
Notices & Proceedings PDFs.

```bash
cd registration_subsidy
python3 -m regsubsidy --vosa-dir ../source/vosa --txc-zip /path/to/S.zip \
  --out output_phase3 --no-jev --noc-xml source/nocrecords.xml --np-refs source/np_registrations.csv
python3 -m regsubsidy.route_subsidy --dataset output_phase3/service_subsidy_dataset.csv --out ../route_subsidy.csv
```
