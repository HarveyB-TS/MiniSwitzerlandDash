# Methods and interpretation

## Boundaries and Census geography

The source study areas are indicative pre-feasibility envelopes supplied by the user. Candidate IDs are normalised to stable `candidate_01` to `candidate_07`. Geometry is transformed from WGS84 to British National Grid for intersection calculations. The original files remain under inputs/study_areas.

Resident population uses 2022 Data Zone population from the evidence GeoPackage. A whole zone has weight one. A partial zone receives its intersected area divided by total zone area. This assumes an even distribution within that zone. Counts are estimates and retain decimals. `area_zone_allocation.csv` exposes every weight. Water, mountains and clustered settlement patterns can make this approximation weak.

Output Area car counts are aggregated to 2022 Data Zones using the supplied OA22/DZ22/IZ22 lookup, then allocated with the same area weights. Workplace and daytime tables are processed separately from their mutually exclusive source categories. They are not added to resident population.

The `car_dash_policy` configuration is `zero`. Dash counts in the supplied UV405 table are converted to zero following the [Geographic Data Service preprocessing for this NRS download](https://raw.githubusercontent.com/GeographicDataService/unified-uk-census-2021-22/main/src/census_download_scripts/scot_script.py). That code reads dashes as missing and subsequently fills them with zero. This is an explicitly adopted preprocessing convention, rather than an independently verified NRS definition. True blank cells remain missing. Set the policy to `missing` to withhold any affected candidate aggregate. Generic numeric parsing in other tables continues to preserve dashes as missing. Census disclosure-control effects remain part of the published counts.

## OD travel markets

Work corridor totals use Table 5a, Study totals use Table 8a. Work mode detail uses Table 6a and Study mode detail uses Table 9a. The `purpose` and `series` columns distinguish them. Destinations outside the area remain in the export.

Data Zone origin flows use the area-overlap allocation. Intermediate Zone mode flows use an origin weight based on the candidate's allocated DZ population divided by the IZ population. This is an estimate of candidate-origin flows. The two series are alternative views and must not be summed. Observed 2022 travel markets cannot establish suppressed demand or forecast future ridership.

## Timetable supply and gateways

The original QGIS toolkit cache builder and candidate profiler supply all network calculations. The source GTFS feed downloaded on 6 October 2026 reports validity 5 October to 28 December 2026. The common analysis day is Monday 12 October 2026. Feed version is retained in the network tables.

An active trip serving the candidate is counted once within that candidate. Routes and their external calls are retained beyond the polygon. Different areas can share a trip, so the sum across areas is an area-observation total, rather than a count of unique national trips. Hourly unique trips can also appear in more than one hour. Operating span and maximum gaps describe scheduled activity, with the profiler's original call-selection method.

The supplied gateway points identify Oban and Mallaig rail/ferry locations. The profiler is configured with their exact GTFS stop/place identifiers. It examines the candidate-serving network and same-place onward windows of 15, 30 and 60 minutes, using zero minimum transfer time. Rail and ferry parent places are separate. Walking between them, transfer feasibility, minimum interchange times and all external network arrivals are not modelled. A zero or blank result cannot establish that no usable connection exists. Invalid/absent waits remain blank rather than being reported as zero-minute waits.

The overview Power BI map uses a representative point within each area. Full routes, stop and gateway layers are in the QGIS project and per-area GeoPackages. Simplified route GeoJSON uses a 60-metre tolerance for display and retains external route geometry.

## Subsidy matches

Exact NOC operator identifiers and exact route numbers are compared with source records valid on the analysis date. Substring and fuzzy matching are not used. Multiple candidate source matches remain ambiguous. Unmatched, expired and ambiguous services retain Unknown. Source registration confidence, status, activity and ambiguity are preserved. Funder text and its observed/assumed basis remain separate.

`fact_subsidy_services` has one record per area, date and GTFS bus route. A repeated service_key can represent one source registration matched to several GTFS routes. Service shares count distinct service_key values. Trip shares sum scheduled bus trips. They answer different questions. Supported trip share combines Subsidised and Partly subsidised, with Unknown retained in all-bus denominators. No expenditure or contractual powers are inferred.

The full 1,550-record source audit includes records outside these candidates. Such records are not automatically evidence of failed national matching.

## Context and deferred work

Urban Rural Classification 2022 is intersected with each candidate. Shares are proportions of the classified intersected land, rather than resident population shares. Unclassified water/land is outside that denominator.

Historical SIMD and SABI exports retain 2011 zone IDs and original periods. Ranks and deciles are not averaged or joined directly to 2022 zone IDs. These records support QGIS scrutiny and remain outside current headline totals and the primary Power BI model.

R5 accessibility is deferred. The empty table specifies scenario, origins, departure window, threshold and journey criteria. Scenario cost, accessibility gains and qualitative enthusiasm require additional evidence. No composite score is generated.

## Useful follow-up analysis

Compare whole-zone and partial-zone contributions; tighten envelopes around settlements; assess weekday versus weekend and seasonal supply using the same date-selection rule; and model actual walking transfers at Oban/Mallaig before discussing interchange success. These enquiries can change the interpretation of the current comparison more than an additional headline score.
