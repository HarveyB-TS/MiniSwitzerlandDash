# Refresh and QGIS

All configuration paths are relative to `config/project.json`. Move the complete folder without changing those paths. The Power BI DataFolder parameter is separate and is set in Desktop.

## Ordinary refresh

Install the dependencies in requirements.txt into a Python virtual environment. Run `python scripts/refresh.py`, then `python scripts/validate_data.py`. Existing network profiles are reused. The cleaned exports are rebuilt in a staging folder and replace the previous exports after processing completes. SQLite is recreated by validation. Refresh Power BI afterwards.

## New timetable date, feed or boundary

Change reference_date or candidate_geojson in config/project.json. Gateway identifiers are configured per area in config/gateways.json. Run refresh with --network and --qgis-python. Changing a date or polygon without regenerating profiles can leave inconsistent inputs; network regeneration is required for those changes.

The QGIS interpreter must resolve qgis.core and the installed QGIS providers. On Windows, use the QGIS/OSGeo4W environment provided by the installed distribution. On this Mac the tested interpreter was `/Applications/QGIS-final-4_2_3.app/Contents/MacOS/python`. This is an installation-specific example.

For a new GTFS feed, change both gtfs_source and gtfs_cache to new file paths. The cache source manifest records the feed SHA-256. A mismatching feed or an existing cache without provenance is refused. Keep the full national source for external connections. The cache builder and profiler remain the supplied toolkit implementations.

Network regeneration writes per-area GeoPackages, profile JSON and HTML, plus Candidate_analysis.qgz. Native profile HTML can be opened directly for audit. The QGIS project displays full routes, stops and selected gateway points. Map sources use relative paths. Keep qgis_outputs, data and inputs together.

## QGIS Processing entry point

Copy toolkit/dashboard_data_qgis.py into the QGIS Processing scripts folder. Refresh scripts in the Processing toolbox. Supply the project.json path, scripts/refresh.py path and the interpreter with the Python dependencies installed. This entry point builds the cleaned dashboard tables from existing network profiles. Use the batch network command above when changing network scope.

## Optional later inputs

Set accessibility_csv to a CSV matching fact_accessibility in data/schemas.json. Each row must identify the area/date, scenario and baseline/scenario type, origin definition, departure window, travel-time limit and journey criteria. These assumptions are mandatory. R5 execution itself is outside this handover. Add the accessibility table to the BI model when results are available and reviewed.

additional_imports accepts schema-conforming fact_population or fact_accessibility inputs. Do not append duplicate population grains. Validate after importing. The primary source-driven Census pipeline is preferable for routine refreshes.

urban_rural_folder contains the supplied 2022 shapefile in British National Grid. Historical SIMD/SABI are read from the original evidence GeoPackage and exported at 2011 zone grain. They remain outside the primary Power BI model.

## Report editing and validation tools

Routine refresh requires Python and QGIS only when needed. pbir-cli and Tabular Editor are development tools. pbir-cli was used for report mutations and Tabular Editor CLI for TMDL conversion, model changes and static DAX checks. The preview Tabular Editor binary is time-limited and is not shipped as a client dependency.

The conversion retained compatibility level 1600. Tabular Editor's best-practice gate asking for the latest compatibility level was explicitly waived for serialisation; model semantic validation still ran. This was a compatibility choice, rather than a claim that all best-practice rules passed.
