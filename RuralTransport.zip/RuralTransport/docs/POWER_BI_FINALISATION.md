# Complete and check the Power BI handover

The PBIP is an editable thick report using a local TMDL semantic model. This Mac cannot run Power BI Desktop. Structural validation is distinct from a successful Desktop refresh and rendered report.

1. Extract the complete report and data folders to a short local Windows path. Retain `RuralCandidates.Report` and `RuralCandidates.SemanticModel` alongside `RuralCandidates.pbip`.
2. Use current Power BI Desktop. Enable Power BI Project and enhanced report-format features where the installed version requires them. Close and reopen Desktop after changing preview settings.
3. Open `RuralCandidates.pbip`.
4. In Transform data > Manage parameters, change `DataFolder` to the actual data directory, including its trailing separator. The supplied default points to the author's Mac and must be changed. All twelve imported tables read this parameter.
5. Apply changes and refresh. Check decimal columns and dates use the intended types and that CSV blank values stay null. There are no remote database credentials.
6. Compare the seven population and timetable results with `data/fact_population.csv` and `data/fact_network_supply.csv`. Compare supported bus shares with `fact_subsidy_services.csv`, retaining Unknown in the denominator.
7. Select two study areas. Both should remain visible in the comparison table and selected-indicator chart. Select exactly one indicator. Values from different units should never be added into one score.
8. Check the area and date slicers synchronise between pages. Check Work and Study filters separate the OD series. Corridor totals use Table 5a/8a; mode detail uses Table 6a/9a. These two series must never be added together.
9. Select an area on the map. Check the comparison visuals respond. Native map availability depends on Desktop/tenant settings. This map displays representative study-area points. Polygon boundaries and route lines are supplied in GeoJSON and the QGIS project.
10. Check route and category selections on the network and subsidy pages. The main model deliberately uses single-direction dimension-to-fact relationships. Selecting a fact-table row will not filter unrelated facts unless a shared dimension drives the selection.
11. Right-click an area name in the comparison table and drill through to Study-area detail. Confirm the area is retained and the Back button returns to the earlier selection. Check the button with Ctrl-click while editing.
12. Inspect all five pages at normal window size. Verify the dropdown slicers, table column widths, map and Back button. Structural QA reports contain advisory size/field-count warnings that require visual judgement.
13. Save the completed project, then File > Save As > Power BI report (.pbix). Open that PBIX independently and repeat refresh and interaction checks. Record Desktop version, test date and any changes in the validation record.

No publication or Fabric deployment was performed. Do not describe Desktop refresh, visual rendering, DAX runtime results or PBIX compilation as tested until these steps have passed.

To edit report definitions, use pbir-cli. To edit model metadata, use Tabular Editor or Power BI Desktop. Do not regenerate the report using the older development generator.
