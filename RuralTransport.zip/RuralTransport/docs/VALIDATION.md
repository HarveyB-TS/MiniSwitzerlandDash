# Validation and acceptance record

Data reconciliation passed for all seven supplied areas. Power BI structural checks passed; Desktop runtime acceptance remains pending.

| Check | Result | Evidence |
|---|---|---|
| CSV contracts, keys, numeric values and source references | Passed | validation_report.json |
| Active trips and routes agree with original QGIS profiles | Passed, seven areas | validation_report.json |
| Subsidy bus-trip denominators reconcile with supply | Passed, seven areas | validation_report.json |
| Subsidy ambiguity, expiry, Unknown and funding provenance tests | Passed | ../test_results.log |
| PBIP paths, identities, formats and theme resources | Passed | pbip_validation.json |
| Report schemas and local model field references | Passed, with layout advisories | pbir_validation.json |
| Published Microsoft JSON schemas | Passed | powerbi_schema_validation.json |
| Static TMDL/DAX model validation | Passed | model_validation.json |
| Power BI Desktop opening, refresh, rendering and interactions | Pending | POWER_BI_FINALISATION.md |
| Compiled PBIX | Pending Windows Desktop acceptance | POWER_BI_FINALISATION.md |
| R5 scenarios and accessibility | Deferred by user | Empty fact_accessibility contract |

## Current comparison snapshot

Population and car figures below are overlap estimates, rounded for this record. Underlying tables retain precision. Timetable counts refer to Monday 12 October 2026.

| Study area | Estimated residents | No-car household share | Scheduled trips | Routes | Partial / intersected DZs |
|---|---:|---:|---:|---:|---:|
| Highland Perthshire | 13,112 | 12.9% | 262 | 23 | 13 / 24 |
| Mid & West Galloway | 26,993 | 17.4% | 202 | 19 | 13 / 44 |
| East Sutherland | 17,797 | 15.9% | 138 | 14 | 8 / 29 |
| Badenoch & Strathspey | 12,266 | 13.3% | 219 | 20 | 12 / 24 |
| SE Loch Lomond & Trossachs | 75,823 | 24.4% | 1,220 | 38 | 33 / 127 |
| Central Borders | 51,124 | 22.2% | 400 | 21 | 14 / 76 |
| Skye | 10,739 | 15.4% | 154 | 21 | 9 / 17 |

## Remaining interpretation limits

The supplied envelopes can include sizeable settlements at their edges. Compare boundary alternatives before interpreting trips per resident. Area observations can overlap, so summing candidates does not identify unique national trips or people. Gateway windows have no walking or minimum-transfer model. Published registration subsidy status is an inferred match with a separate Unknown category. Historical access context retains older zone IDs and dates.

Structural layout warnings concern short dropdown slicers, wide audit tables and recommended field limits. They do not prove a rendering failure; assess them in Desktop. No claims of visual or runtime success are made.

Tooling note: Tabular Editor compatibility-level best-practice advice was waived for conversion while retaining compatibility level 1600. Static semantic validation was subsequently run and passed.
