import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from subsidy import match
from common import number
class Contracts(unittest.TestCase):
 def source(self,**kwargs):return dict(operator_code='ABC',route='10',subsidy_category='Unknown',txc_start_date='',txc_end_date='',**kwargs)
 def network(self):return [dict(mode='Bus',agency_id='agency',route_number='10',area_id='A',route_id='r1',operator='Operator',scheduled_trips=8)]
 def run_match(self,rs):return match(rs,self.network(),{'agency':'ABC'},'2026-10-12','source',lambda *a:None)[0][0]
 def test_unknown_is_not_unsubsidised(self):self.assertEqual(self.run_match([self.source()])['category'],'Unknown')
 def test_duplicate_matching_sources_are_ambiguous(self):
  r=self.run_match([self.source(),self.source()]);self.assertEqual(r['category'],'Unknown');self.assertEqual(r['gtfs_match_status'],'Ambiguous')
 def test_expired_service_is_not_used(self):
  r=self.source();r['txc_end_date']='2026-10-01';out=self.run_match([r]);self.assertEqual(out['gtfs_match_status'],'Source service out of date')
 def test_assumed_funding_remains_assumed(self):
  r=self.source(subsidy_funder_source='council in-house (assumed)',subsidy_funder='Council');self.assertEqual(self.run_match([r])['funding_basis'],'council in-house (assumed)')
 def test_route_number_substring_does_not_match(self):
  r=self.source();r['route']='110';self.assertEqual(self.run_match([r])['gtfs_match_status'],'Unmatched')
 def test_dash_remains_missing_and_zero_remains_zero(self):self.assertIsNone(number('-'));self.assertEqual(number('0'),0)
 def test_car_dash_policy_is_explicit_and_blanks_remain_missing(self):
  import tempfile
  from demographics import population
  with tempfile.TemporaryDirectory() as folder:
   p=Path(folder)/'census_2022_car_availability.csv'
   def result(cell,policy):
    p.write_text('metadata\nmetadata\nmetadata\nOA,total,no_car\nOA1,10,'+cell+'\n')
    return population(Path(folder),[{'area_id':'A','population':20}],{}, {'OA1':'DZ1'},{'A':{'DZ1':1}},'2026-10-12','s',policy)[0]['households_no_car']
   self.assertEqual(result('-',True),0)
   self.assertIsNone(result('-',False))
   self.assertIsNone(result('',True))
if __name__=='__main__':unittest.main()
